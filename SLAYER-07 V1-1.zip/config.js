/*
Created By Rayzz
Tgl Create 16/04/2025
*/

const fs = require('fs')

//settings bot
global.owner = "6287790214711"
global.namaowner = "YanzX Official"
global.reply = "https://files.catbox.moe/ja698g.jpg"
global.status = true
global.usepairing = true // Ubah False Untuk Qr Code
global.prefa = ["", "!", ".", ",", "🐤", "🗿"]; //not change!!

//mess
global.mess = {
    owner: "\`Fitur Khusus Developer YanzX\`",
    group: "\`Fitur Khusus Di Dalam Group\`",
    private: "\`Fitur Khusus Private Chat\`",
    murbug: "\`Fitur Khusus Pengguna Murbug\`",
    admin: "\`Fitur Khusus Admin Group\`"
}

//nama seticker
global.packname = 'SLAYER - 07 V1'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nYanzX Official'

//End Settings

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
